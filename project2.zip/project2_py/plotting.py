import numpy as np
from matplotlib import pyplot as plt
from project2 import optimize_history
from helpers import Simple1, Simple2, Simple3

def plot_history():
    for p_type in [Simple1, Simple2, Simple3]:
        problem = p_type()
        init_x = problem.x0()
        x_hist, _ = optimize_history(problem.f, problem.g, problem.c, init_x, problem.n, problem.count, problem.prob, debug=False)
        problem.nolimit()
        obj_vals = np.empty(len(x_hist))
        constraint_vals = np.empty([problem._cdim, len(x_hist)])
        print(len(x_hist))
        for pt_idx, pt in enumerate(x_hist):
            obj_vals[pt_idx] = problem.f(pt)
            constraint_vals[:, pt_idx] = problem.c(pt)
        plt.figure()
        plt.plot(obj_vals, label='Objective value during optimization')
        plt.plot(np.zeros_like(obj_vals), label='Optimal objective value')
        plt.title('Convergence plot for ' + problem.prob + ' with initial point ' + str(init_x))
        plt.xlabel('Number of iterations')
        plt.ylabel('f(x)')
        plt.legend()
        plt.figure()
        for i in range(problem._cdim):
            plt.plot(constraint_vals[i, :], label='Constraint value during optimization')
        plt.plot(np.zeros_like(obj_vals), label='Boundary constraint value')
        plt.title('Constraint plot for ' + problem.prob + ' with initial point ' + str(init_x))
        plt.xlabel('Number of iterations')
        plt.ylabel('c(x)')
        plt.legend()
    plt.show()
    return None